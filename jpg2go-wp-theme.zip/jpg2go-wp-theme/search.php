<?php
/**
 * Search results template.
 *
 * @package jpg2go-classic
 */

get_header();
?>
<section class="hero">
    <div class="fade-up">
        <span class="hero-label"><?php esc_html_e('Search Results', 'jpg2go-classic'); ?></span>
        <h1>
            <?php
            printf(
                esc_html__('Results for: %s', 'jpg2go-classic'),
                '<em>' . esc_html(get_search_query()) . '</em>'
            );
            ?>
        </h1>
    </div>
</section>

<main class="blog-layout">
    <section class="blog-main">
        <?php get_search_form(); ?>
        <div class="blog-list-grid">
            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <article <?php post_class('blog-card'); ?>>
                        <div class="blog-meta"><?php echo esc_html(get_the_date()); ?> - <?php the_author(); ?></div>
                        <h2 class="blog-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="blog-card-excerpt"><?php echo esc_html(get_the_excerpt()); ?></div>
                        <a class="blog-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'jpg2go-classic'); ?></a>
                    </article>
                <?php endwhile; ?>
            <?php else : ?>
                <article class="blog-card">
                    <h2 class="blog-card-title"><?php esc_html_e('No matching posts', 'jpg2go-classic'); ?></h2>
                    <div class="blog-card-excerpt"><?php esc_html_e('Try different keywords to find relevant posts.', 'jpg2go-classic'); ?></div>
                </article>
            <?php endif; ?>
        </div>
        <div class="pagination-wrap">
            <?php the_posts_pagination(); ?>
        </div>
    </section>
    <?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
