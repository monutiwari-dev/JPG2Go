<?php
/**
 * Archive template.
 *
 * @package jpg2go-classic
 */

get_header();
?>
<section class="hero">
    <div class="fade-up">
        <span class="hero-label"><?php esc_html_e('Archive', 'jpg2go-classic'); ?></span>
        <h1><?php the_archive_title(); ?></h1>
        <?php the_archive_description('<p>', '</p>'); ?>
    </div>
</section>

<main class="blog-layout">
    <section class="blog-main">
        <div class="blog-list-grid">
            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <article <?php post_class('blog-card'); ?>>
                        <div class="blog-meta"><?php echo esc_html(get_the_date()); ?> - <?php the_author(); ?></div>
                        <h2 class="blog-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="blog-card-excerpt"><?php echo esc_html(get_the_excerpt()); ?></div>
                        <a class="blog-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'jpg2go-classic'); ?></a>
                    </article>
                <?php endwhile; ?>
            <?php else : ?>
                <article class="blog-card">
                    <h2 class="blog-card-title"><?php esc_html_e('No posts found', 'jpg2go-classic'); ?></h2>
                </article>
            <?php endif; ?>
        </div>
        <div class="pagination-wrap"><?php the_posts_pagination(); ?></div>
    </section>
    <?php get_sidebar(); ?>
</main>
<?php get_footer(); ?>
