<?php
/**
 * Single post template.
 *
 * @package jpg2go-classic
 */

get_header();
?>

<main class="blog-layout">
    <section class="blog-main single-wrap">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article <?php post_class('single-article'); ?>>
            <div class="blog-meta"><?php echo esc_html(get_the_date()); ?> - <?php the_author(); ?></div>
            <h1 class="single-title"><?php the_title(); ?></h1>
            <?php if (has_post_thumbnail()) : ?>
                <div class="single-featured-image">
                    <?php the_post_thumbnail('large', array('loading' => 'eager', 'alt' => wp_strip_all_tags(get_the_title()))); ?>
                </div>
            <?php endif; ?>
            <div class="single-content">
                <?php the_content(); ?>
            </div>
            <div class="pagination-wrap">
                <?php wp_link_pages(); ?>
            </div>
            <div class="single-post-nav">
                <div><?php previous_post_link('%link', '&larr; Previous Post'); ?></div>
                <div><?php next_post_link('%link', 'Next Post &rarr;'); ?></div>
            </div>
        </article>
    <?php endwhile; endif; ?>
    </section>
    <?php get_sidebar(); ?>
</main>

<?php get_footer(); ?>
