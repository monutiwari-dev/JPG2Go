<?php
/**
 * Theme setup for JPG2Go Classic.
 *
 * @package jpg2go-classic
 */

if (!defined('ABSPATH')) {
    exit;
}

function jpg2go_classic_setup() {
    load_theme_textdomain('jpg2go-classic', get_template_directory() . '/languages');

    add_theme_support('title-tag');
    add_theme_support('automatic-feed-links');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 240,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

    $GLOBALS['content_width'] = 820;

    register_nav_menus(
        array(
            'primary' => __('Primary Menu', 'jpg2go-classic'),
        )
    );

    add_image_size('jpg2go-card', 720, 405, true);
}
add_action('after_setup_theme', 'jpg2go_classic_setup');

function jpg2go_classic_assets() {
    wp_enqueue_style('jpg2go-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=DM+Mono:wght@400;500&family=DM+Sans:wght@300;400;500;600&display=swap', array(), null);
    wp_enqueue_style('jpg2go-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));
    wp_enqueue_script('jpg2go-script', get_template_directory_uri() . '/assets/js/theme.js', array(), wp_get_theme()->get('Version'), true);
}
add_action('wp_enqueue_scripts', 'jpg2go_classic_assets');

function jpg2go_classic_excerpt_length() {
    return 24;
}
add_filter('excerpt_length', 'jpg2go_classic_excerpt_length');

/**
 * Blog index, archives, and search: 10 posts per page with pagination.
 */
function jpg2go_classic_blog_posts_per_page($query) {
    if (is_admin() || !$query->is_main_query()) {
        return;
    }

    if ($query->is_home() || $query->is_archive() || $query->is_search()) {
        $query->set('posts_per_page', 10);
    }
}
add_action('pre_get_posts', 'jpg2go_classic_blog_posts_per_page');

function jpg2go_classic_widgets_init() {
    register_sidebar(array(
        'name'          => __('Blog Sidebar', 'jpg2go-classic'),
        'id'            => 'blog-sidebar',
        'description'   => __('Widgets in this area appear on blog pages.', 'jpg2go-classic'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'jpg2go_classic_widgets_init');

/**
 * Base URL for the main JPG2Go site (converter + static tool pages).
 * If WordPress lives in a subfolder (e.g. /blog), set "Main site base URL" in Customizer to https://jpg2go.com
 */
function jpg2go_classic_get_static_site_base() {
    $custom = trim((string) get_theme_mod('jpg2go_static_site_url', ''));
    if ($custom !== '') {
        return untrailingslashit(esc_url_raw($custom));
    }

    $home = home_url('/');
    $parts = wp_parse_url($home);
    if (!is_array($parts) || empty($parts['host'])) {
        return untrailingslashit($home);
    }

    $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
    $host   = $parts['host'];
    $port   = isset($parts['port']) ? ':' . (int) $parts['port'] : '';
    $path   = isset($parts['path']) ? trim($parts['path'], '/') : '';

    // If WordPress runs in /blog, tool/legal links should still target the root domain.
    if ($path === 'blog') {
        return $scheme . '://' . $host . $port;
    }

    return untrailingslashit($home);
}

/** Homepage URL for the main/static site (matches sitemap: https://jpg2go.com/). */
function jpg2go_classic_static_home_url() {
    return esc_url(trailingslashit(jpg2go_classic_get_static_site_base()));
}

/**
 * URL for a path on the main site (no trailing slash on slug — matches sitemap).
 *
 * @param string $path e.g. 'about', 'tools', 'image-resizer'.
 */
function jpg2go_classic_static_path_url($path) {
    $path = trim((string) $path, '/');
    if ($path === '') {
        return jpg2go_classic_static_home_url();
    }

    return esc_url(jpg2go_classic_get_static_site_base() . '/' . $path);
}

/** "Convert Now" — original index.html points to #tool on the main homepage. */
function jpg2go_classic_converter_url() {
    return esc_url(jpg2go_classic_get_static_site_base() . '/#tool');
}

/** Blog index (WordPress posts page or /blog). */
function jpg2go_classic_blog_index_url() {
    $home = home_url('/');
    $parts = wp_parse_url($home);
    $path  = isset($parts['path']) ? trim($parts['path'], '/') : '';

    // If WordPress lives at /blog, the blog index is the WP home itself.
    if ($path === 'blog') {
        return home_url('/');
    }

    $page_id = (int) get_option('page_for_posts');
    if ($page_id > 0) {
        return get_permalink($page_id);
    }

    return home_url('/blog');
}

function jpg2go_classic_customize_register($wp_customize) {
    $wp_customize->add_section(
        'jpg2go_classic_site_links',
        array(
            'title'       => __('JPG2Go main site links', 'jpg2go-classic'),
            'description' => __('If this WordPress install is not on your domain root (for example it runs under /blog), enter your main site URL so header/footer links to tools and the converter go to the correct place.', 'jpg2go-classic'),
        )
    );

    $wp_customize->add_setting(
        'jpg2go_static_site_url',
        array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        )
    );

    $wp_customize->add_control(
        'jpg2go_static_site_url',
        array(
            'label'       => __('Main site base URL', 'jpg2go-classic'),
            'description' => __('Example: https://jpg2go.com — leave empty if WordPress is already on the site root.', 'jpg2go-classic'),
            'section'     => 'jpg2go_classic_site_links',
            'type'        => 'url',
        )
    );
}
add_action('customize_register', 'jpg2go_classic_customize_register');
