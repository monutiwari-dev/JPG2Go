<?php
/**
 * Sidebar template.
 *
 * @package jpg2go-classic
 */
?>
<aside class="blog-sidebar">
    <?php if (is_active_sidebar('blog-sidebar')) : ?>
        <?php dynamic_sidebar('blog-sidebar'); ?>
    <?php else : ?>
        <section class="widget">
            <h3 class="widget-title"><?php esc_html_e('Categories', 'jpg2go-classic'); ?></h3>
            <ul>
                <?php wp_list_categories(array('title_li' => '')); ?>
            </ul>
        </section>
    <?php endif; ?>
</aside>
