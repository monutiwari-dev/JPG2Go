<?php
/**
 * Comments template.
 *
 * @package jpg2go-classic
 */

if (post_password_required()) {
    return;
}
?>

<section class="comments-wrap">
    <?php if (have_comments()) : ?>
        <h2 class="comments-title">
            <?php
            printf(
                esc_html(_nx('%1$s Comment', '%1$s Comments', get_comments_number(), 'comments title', 'jpg2go-classic')),
                esc_html(number_format_i18n(get_comments_number()))
            );
            ?>
        </h2>

        <ol class="comment-list">
            <?php
            wp_list_comments(array(
                'style'      => 'ol',
                'short_ping' => true,
            ));
            ?>
        </ol>

        <?php the_comments_pagination(); ?>
    <?php endif; ?>

    <?php comment_form(); ?>
</section>
