<?php
/**
 * Blog index template.
 *
 * @package jpg2go-classic
 */

get_header();
?>

<section class="hero">
    <div class="fade-up">
        <span class="hero-label">Blog</span>
        <h1>Latest <em>Updates</em></h1>
        <p>News, tutorials, product updates, and helpful guides from JPG2Go.</p>
    </div>
</section>

<main class="blog-layout">
    <section class="blog-main">
        <div class="blog-list-grid">
            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <article <?php post_class('blog-card'); ?>>
                        <div class="blog-meta"><?php echo esc_html(get_the_date()); ?> - <?php the_author(); ?></div>
                        <h2 class="blog-card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <div class="blog-card-excerpt"><?php echo esc_html(get_the_excerpt()); ?></div>
                        <a class="blog-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'jpg2go-classic'); ?></a>
                    </article>
                <?php endwhile; ?>
            <?php else : ?>
                <article class="blog-card">
                    <h2 class="blog-card-title"><?php esc_html_e('No posts found', 'jpg2go-classic'); ?></h2>
                    <div class="blog-card-excerpt"><?php esc_html_e('There are no posts to display yet.', 'jpg2go-classic'); ?></div>
                </article>
            <?php endif; ?>
        </div>

        <div class="pagination-wrap">
            <?php the_posts_pagination(); ?>
        </div>
    </section>
    <?php get_sidebar(); ?>
</main>

<?php get_footer(); ?>
