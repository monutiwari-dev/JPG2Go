<?php
/**
 * Front page template.
 *
 * @package jpg2go-classic
 */

get_header();
?>

<section class="hero">
    <div class="fade-up">
        <span class="hero-label">WordPress Blog</span>
        <h1>JPG2<em>Go</em> Blog</h1>
        <p>Latest updates, tutorials, announcements, and product news published directly from your WordPress dashboard.</p>
    </div>
</section>

<section class="content-section latest-updates-section" id="blog">
    <div class="latest-updates-header">
        <span class="latest-updates-label"><?php esc_html_e('Latest Updates', 'jpg2go-classic'); ?></span>
    </div>
    <div class="latest-updates-grid">
        <?php
        $home_posts = new WP_Query(
            array(
                'post_type'      => 'post',
                'posts_per_page' => 3,
            )
        );

        if ($home_posts->have_posts()) :
            while ($home_posts->have_posts()) :
                $home_posts->the_post();
                ?>
                <article class="latest-update-card">
                    <a href="<?php the_permalink(); ?>" class="latest-update-card__media">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php
                            the_post_thumbnail(
                                'jpg2go-card',
                                array(
                                    'class'   => 'latest-update-card__img',
                                    'loading' => 'lazy',
                                    'alt'     => wp_strip_all_tags(get_the_title()),
                                )
                            );
                            ?>
                        <?php else : ?>
                            <span class="latest-update-card__placeholder" aria-hidden="true"></span>
                        <?php endif; ?>
                    </a>
                    <div class="latest-update-card__body">
                        <time class="latest-update-card__date" datetime="<?php echo esc_attr(get_the_date(DATE_W3C)); ?>"><?php echo esc_html(get_the_date()); ?></time>
                        <h3 class="latest-update-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p class="latest-update-card__excerpt"><?php echo esc_html(get_the_excerpt()); ?></p>
                        <a class="latest-update-card__link" href="<?php the_permalink(); ?>"><?php esc_html_e('Read article', 'jpg2go-classic'); ?><span class="latest-update-card__arrow" aria-hidden="true">→</span></a>
                    </div>
                </article>
                <?php
            endwhile;
            wp_reset_postdata();
        else :
            ?>
            <article class="latest-update-card latest-update-card--empty">
                <div class="latest-update-card__body">
                    <h3 class="latest-update-card__title"><?php esc_html_e('No posts yet', 'jpg2go-classic'); ?></h3>
                    <p class="latest-update-card__excerpt"><?php esc_html_e('Publish your first post from the WordPress dashboard. Featured images will appear on these cards automatically.', 'jpg2go-classic'); ?></p>
                </div>
            </article>
            <?php
        endif;
        ?>
    </div>
    <p class="latest-updates-cta">
        <a class="btn-primary" href="<?php echo esc_url(jpg2go_classic_blog_index_url()); ?>"><?php esc_html_e('View All Blog Posts', 'jpg2go-classic'); ?></a>
    </p>
</section>

<?php get_footer(); ?>
