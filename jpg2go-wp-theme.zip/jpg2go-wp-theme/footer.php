<?php
/**
 * Site footer.
 *
 * @package jpg2go-classic
 */
?>
<footer>
    <div class="footer-inner">
        <div class="footer-grid">
            <div class="footer-brand">
                <a href="<?php echo jpg2go_classic_static_home_url(); ?>" class="logo">JPG2<span>Go</span></a>
                <p><?php esc_html_e('Free browser-based image conversion. Zero upload, zero account, zero limits. Convert JPG, PNG, WebP, AVIF, GIF and BMP instantly.', 'jpg2go-classic'); ?></p>
                <div class="footer-social">
                    <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Facebook" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    </a>
                    <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Twitter" class="social-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
                    </a>
                </div>
            </div>
            <div>
                <div class="footer-col-title"><?php esc_html_e('Image Tools', 'jpg2go-classic'); ?></div>
                <ul class="footer-links">
                    <li><a href="<?php echo jpg2go_classic_static_path_url('image-resizer'); ?>"><?php esc_html_e('Image Resizer', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('compress-jpeg'); ?>"><?php esc_html_e('Compress JPEG', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('background-remover'); ?>"><?php esc_html_e('Background Remover', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('ai-image-enhancer'); ?>"><?php esc_html_e('AI Image Enhancer', 'jpg2go-classic'); ?></a></li>
                </ul>
            </div>
            <div>
                <div class="footer-col-title"><?php esc_html_e('PDF Tools', 'jpg2go-classic'); ?></div>
                <ul class="footer-links">
                    <li><a href="<?php echo jpg2go_classic_static_path_url('jpg-to-pdf'); ?>"><?php esc_html_e('JPG to PDF', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('pdf-to-jpg'); ?>"><?php esc_html_e('PDF to JPG', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('merge-pdf'); ?>"><?php esc_html_e('Merge PDF', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('compress-pdf'); ?>"><?php esc_html_e('Compress PDF', 'jpg2go-classic'); ?></a></li>
                </ul>
            </div>
            <div>
                <div class="footer-col-title"><?php esc_html_e('Legal Pages', 'jpg2go-classic'); ?></div>
                <ul class="footer-links">
                    <li><a href="<?php echo jpg2go_classic_static_path_url('about'); ?>"><?php esc_html_e('About', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('terms'); ?>"><?php esc_html_e('Terms', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo jpg2go_classic_static_path_url('privacy-policy'); ?>"><?php esc_html_e('Privacy Policy', 'jpg2go-classic'); ?></a></li>
                    <li><a href="<?php echo esc_url(jpg2go_classic_blog_index_url()); ?>"><?php esc_html_e('Blog', 'jpg2go-classic'); ?></a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <span><?php echo esc_html(date_i18n('Y')); ?> <a href="<?php echo jpg2go_classic_static_home_url(); ?>" style="color:inherit;text-decoration:none;">JPG2Go</a>. <?php esc_html_e('All conversions run client-side - your images are never stored or transmitted.', 'jpg2go-classic'); ?></span>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
