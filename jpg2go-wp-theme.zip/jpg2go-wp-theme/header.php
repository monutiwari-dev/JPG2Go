<?php
/**
 * Site header.
 *
 * @package jpg2go-classic
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header>
    <div class="header-inner">
        <a href="<?php echo jpg2go_classic_static_home_url(); ?>" class="logo">JPG2<span>Go</span></a>

        <nav class="main-nav" aria-label="<?php esc_attr_e('Primary menu', 'jpg2go-classic'); ?>">
            <?php if (has_nav_menu('primary')) : ?>
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'primary',
                        'container'      => false,
                        'fallback_cb'    => false,
                        'items_wrap'     => '%3$s',
                    )
                );
                ?>
            <?php else : ?>
                <a href="<?php echo jpg2go_classic_static_home_url(); ?>"><?php esc_html_e('Home', 'jpg2go-classic'); ?></a>
                <a href="<?php echo jpg2go_classic_static_path_url('about'); ?>"><?php esc_html_e('About', 'jpg2go-classic'); ?></a>
                <a href="<?php echo jpg2go_classic_static_path_url('tools'); ?>"><?php esc_html_e('Tools', 'jpg2go-classic'); ?></a>
            <?php endif; ?>
            <a href="<?php echo jpg2go_classic_converter_url(); ?>" class="nav-cta"><?php esc_html_e('Convert Now', 'jpg2go-classic'); ?></a>
        </nav>

        <button class="mobile-menu-toggle" id="mobileMenuToggle" aria-label="<?php esc_attr_e('Toggle menu', 'jpg2go-classic'); ?>">
            <span></span><span></span><span></span>
        </button>
    </div>

    <nav class="mobile-nav" id="mobileNav" aria-label="<?php esc_attr_e('Mobile menu', 'jpg2go-classic'); ?>">
        <a href="<?php echo jpg2go_classic_static_home_url(); ?>"><?php esc_html_e('Home', 'jpg2go-classic'); ?></a>
        <a href="<?php echo jpg2go_classic_static_path_url('about'); ?>"><?php esc_html_e('About', 'jpg2go-classic'); ?></a>
        <a href="<?php echo jpg2go_classic_static_path_url('tools'); ?>"><?php esc_html_e('Tools', 'jpg2go-classic'); ?></a>
        <a href="<?php echo jpg2go_classic_converter_url(); ?>" class="nav-cta"><?php esc_html_e('Convert Now', 'jpg2go-classic'); ?></a>
    </nav>
</header>
