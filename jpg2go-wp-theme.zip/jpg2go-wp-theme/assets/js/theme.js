(function () {
  "use strict";

  var mobileToggle = document.getElementById("mobileMenuToggle");
  var mobileNav = document.getElementById("mobileNav");

  if (mobileToggle && mobileNav) {
    mobileToggle.addEventListener("click", function (e) {
      e.stopPropagation();
      mobileToggle.classList.toggle("active");
      mobileNav.classList.toggle("active");
    });

    document.addEventListener("click", function (e) {
      if (!mobileNav.contains(e.target) && !mobileToggle.contains(e.target)) {
        mobileToggle.classList.remove("active");
        mobileNav.classList.remove("active");
      }
    });
  }
})();
