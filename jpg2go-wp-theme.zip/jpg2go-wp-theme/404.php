<?php
/**
 * 404 template.
 *
 * @package jpg2go-classic
 */

get_header();
?>
<section class="hero">
    <div class="fade-up">
        <span class="hero-label">404</span>
        <h1><?php esc_html_e('Page Not Found', 'jpg2go-classic'); ?></h1>
        <p><?php esc_html_e('The page you are looking for does not exist or has been moved.', 'jpg2go-classic'); ?></p>
    </div>
</section>

<main class="single-wrap">
    <div class="content-prose">
        <p><?php esc_html_e('Try searching for a post or go back to the homepage.', 'jpg2go-classic'); ?></p>
    </div>
    <?php get_search_form(); ?>
    <p style="margin-top:1rem;">
        <a class="btn-primary" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Back to Home', 'jpg2go-classic'); ?></a>
    </p>
</main>
<?php get_footer(); ?>
