<?php
/**
 * Page template.
 *
 * @package jpg2go-classic
 */

get_header();
?>

<main class="single-wrap">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article <?php post_class(); ?>>
            <h1 class="single-title"><?php the_title(); ?></h1>
            <div class="single-content">
                <?php the_content(); ?>
            </div>
            <div class="pagination-wrap">
                <?php wp_link_pages(); ?>
            </div>
        </article>
    <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>
